int placement(int *GAMESTATE, WINDOW** game_maps, WINDOW** inventory);
int validity_check();