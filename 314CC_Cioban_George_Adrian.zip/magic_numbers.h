//number of options in the main menu
#define OPTION_COUNT    3

//main window parameters
#define MAIN_SCREEN_Y   0
#define MAIN_SCREEN_X   0
#define MAIN_SCREEN_H   32
#define MAIN_SCREEN_W   128

//button positions
#define BUTTON_Y        MAIN_SCREEN_H/2 + MAIN_SCREEN_Y + (OPTION_COUNT + 1)*i
#define BUTTON_X        MAIN_SCREEN_W/2 - 20/2

//battleship title splash window
#define TITLE_H         13
#define TITLE_W         124
#define TITLE_Y         2
#define TITLE_X         2
#define TITLE_TXT_COLS  69
#define TITLE_TXT_LINES 5
#define TITLE_WRITING_Y (TITLE_H - TITLE_TXT_LINES)/2 
#define TITLE_WRITING_X (TITLE_W - TITLE_TXT_COLS)/2

//parameters of a single game map cell
#define cellWidth       3
#define cellHeight      2


