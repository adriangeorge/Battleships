//color codes
#define BACKGROUND_COLOR    1
#define MENU_BUTTONS        2
#define SELECTED_TEXT       3
#define GAMEGRID_BLUE       4
#define GAMEGRID_CYAN       5
#define INVENTORY           6
#define TITLE_BOX           7
#define SHIP_DRAW           8
#define PLACE_VALID         9
#define PLACE_INVALID       10

void color_init();