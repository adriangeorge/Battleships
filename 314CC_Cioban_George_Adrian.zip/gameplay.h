int gameplay(int *GAMESTATE, WINDOW** game_maps, WINDOW* background, char* map);
int computerTurn(int array[10][10] , int* turn, int* counter);