void file_storage(ship* ships, char* filename);
void random_placement(WINDOW* game_map, ship* SHIP, int* deployedCount);
void readships(ship* ships, char* filename );
void generate_shipArray(ship* ships, int array[10][10]);